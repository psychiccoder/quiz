package com.example.flutter_riverpod_quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
