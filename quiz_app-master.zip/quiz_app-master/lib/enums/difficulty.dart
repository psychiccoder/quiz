enum Difficulty {
  any,
  easy,
  medium,
  hard,
}
